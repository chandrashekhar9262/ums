package university.management.system;

import javax.swing.*;
import java.awt.*;

public class About extends JFrame {

    About() {
        
        setTitle("Project Developer Details");
        setSize(800, 500);
        setLocation(400, 150);
        getContentPane().setBackground(Color.WHITE);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/mypic.jpg"));
        Image i2 = i1.getImage().getScaledInstance(300, 200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(450, 0, 200, 200);
        add(image);
        
        JLabel heading = new JLabel("<html>University<br/>Management System</html>");
        heading.setBounds(70, 20, 300, 130);
        heading.setForeground(Color.GREEN);
        heading.setFont(new Font("Cambria", Font.BOLD, 36));
        add(heading);
        
        JLabel name = new JLabel("Developed By: Chandra Shekhar and Team");
        name.setBounds(70, 220, 700, 40);
        name.setFont(new Font("Cambria", Font.BOLD, 30));
        add(name);
        
        JLabel rollno = new JLabel("Roll number: 12215978");
        rollno.setBounds(70, 260, 550, 40);
        rollno.setFont(new Font("Cambria", Font.PLAIN, 20));
        add(rollno);
        
        JLabel contact = new JLabel("kchandrashekhar1603@gmail.com");
        contact.setBounds(70, 300, 550, 40);
        contact.setFont(new Font("Cambria", Font.PLAIN, 20));
        add(contact);
        
        JLabel nilesh = new JLabel("Nilesh Gehlot: 12224026");
        nilesh.setBounds(70, 360, 550, 40);
        nilesh.setFont(new Font("Cambria", Font.BOLD, 24));
        add(nilesh);
        
        JLabel rohit = new JLabel("Rohit Kumar: 12219614");
        rohit.setBounds(410, 290, 550, 40);
        rohit.setFont(new Font("Cambria", Font.BOLD, 24));
        add(rohit);
        
        JLabel sandeep = new JLabel("Sandeep Kumar: 12218624");
        sandeep.setBounds(410, 360, 550, 40);
        sandeep.setFont(new Font("Cambria", Font.BOLD, 24));
        add(sandeep);
        
        setLayout(null);
        
        setVisible(true);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args) {
        new About();
    }
}
